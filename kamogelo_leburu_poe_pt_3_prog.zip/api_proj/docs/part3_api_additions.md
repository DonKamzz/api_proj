# RaceDay API - additions made in Part 3

The Part 1 endpoint plan (`api_endpoint_plan.md` / `RaceDay_API_Endpoint_Plan.docx`) is still implemented in full.
Part 3 adds the endpoints below because the MVC interface and Azure Blob Storage need them. They follow the same
conventions as Part 1 (same role names, same status codes, same `{ "message": "..." }` error body).

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| GET | `/api/events/mine` | Lists the events created by the logged-in Organiser, with an `enrolmentCount` for each (Organiser dashboard). | Organiser | None | `200 OK` - array of events - `401 Unauthorized` - `403 Forbidden` |
| POST | `/api/events/{id}/banner` | Uploads an event banner image to Azure Blob Storage and saves its URL on the event. | Organiser (owner) | `multipart/form-data` with one file field named `file` (JPG, PNG or WEBP, max 5 MB) | `200 OK` - updated event - `400 Bad Request` - not an allowed image - `401` - `403 Forbidden` - not the owning Organiser - `404 Not Found` - `503 Service Unavailable` - image storage unavailable |
| POST | `/api/users/me/profile-picture` | Uploads the logged-in user's profile picture to Azure Blob Storage and saves its URL. | Any | `multipart/form-data` with one file field named `file` (JPG, PNG or WEBP, max 5 MB) | `200 OK` - updated profile - `400 Bad Request` - `401 Unauthorized` - `503 Service Unavailable` |

## Changes to existing endpoints

| Endpoint | Change | Reason |
|---|---|---|
| `DELETE /api/events/{id}` | Now also returns `409 Conflict` when the event already has enrolments. | Enrolments reference the event in the database; deleting it would break them (and previously caused a server error). |
| `PUT /api/users/me` | Body is `{ firstName, lastName, phoneNumber }` only. The profile picture is set through `POST /api/users/me/profile-picture`. | Matches the Part 1 plan and stops a profile edit from wiping the picture URL. |
| `GET /api/events/{id}` and the list endpoints | The event response now includes `enrolmentCount` (only filled in by `/api/events/mine`). | Dashboard "total enrolments per event". |

## Database note

`Users.ProfilePictureUrl` (NVARCHAR(500), nullable) and `Events.BannerImageUrl` already exist in `raceday_schema.sql`.
They now hold Azure Blob Storage URLs.
