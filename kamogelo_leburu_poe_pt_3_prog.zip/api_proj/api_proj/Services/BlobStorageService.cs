using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using System.Net.NetworkInformation;

namespace api_proj.Services;

/// <summary>
/// Stores uploaded images (event banners, profile pictures) in Azure Blob
/// Storage and returns a signed read-only URL that gets saved in the database.
/// Only the API talks to Azure - the MVC app sends files to the API.
/// </summary>
public interface IBlobStorageService
{
    Task<string> UploadImageAsync(IFormFile file, string folder);
}

public class BlobStorageService : IBlobStorageService
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<BlobStorageService> _logger;

    public BlobStorageService(IConfiguration configuration, ILogger<BlobStorageService> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<string> UploadImageAsync(IFormFile file, string folder)
    {
        var connectionString = _configuration["AzureBlobStorage:ConnectionString"];
        var containerName = _configuration["AzureBlobStorage:ContainerName"];
        if (string.IsNullOrWhiteSpace(containerName))
        {
            containerName = "raceday-images";
        }

        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException("Image storage has not been configured on the server.");
        }

        try
        {
            var container = new BlobContainerClient(connectionString, containerName);

            // Private container: images are shown through signed links, so no public access is needed.
            await container.CreateIfNotExistsAsync();

            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            var blob = container.GetBlobClient($"{folder}/{Guid.NewGuid()}{extension}");

            using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });

            // Read-only link that stays valid for five years.
            return blob.GenerateSasUri(BlobSasPermissions.Read, DateTimeOffset.UtcNow.AddYears(5)).ToString();
        }
        catch (RequestFailedException ex)
        {
            _logger.LogError(ex, "Azure Blob Storage upload failed.");
            throw new InvalidOperationException("Image storage is unavailable right now. Please try again later.");
        }
    }

}

/// <summary>Checks an uploaded file really is a small JPG/PNG/WEBP image before it goes to Azure.</summary>
public static class ImageValidator
{
    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".webp" };
    private const long MaxBytes = 5 * 1024 * 1024;

    /// <summary>Returns an error message, or null when the file is acceptable.</summary>
    public static string? Validate(IFormFile? file)
    {
        if (file == null || file.Length == 0)
        {
            return "Please choose an image to upload.";
        }

        if (file.Length > MaxBytes)
        {
            return "The image must be 5 MB or smaller.";
        }

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!AllowedExtensions.Contains(extension) || !file.ContentType.StartsWith("image/"))
        {
            return "Only JPG, PNG or WEBP images are allowed.";
        }

        return null;
    }

}