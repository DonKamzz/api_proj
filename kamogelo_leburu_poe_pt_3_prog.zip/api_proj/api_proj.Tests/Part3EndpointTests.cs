using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using api_proj.DTOs;
using api_proj.Models;
using Xunit;

namespace api_proj.Tests;

/// <summary>
/// Tests for the endpoints added for Part 3: the Organiser dashboard list,
/// image uploads (banner + profile picture) and the safer event delete.
/// None of these tests reach Azure - role checks and file validation run first.
/// </summary>
public class Part3EndpointTests : IClassFixture<ApiProjWebApplicationFactory>
{
    private readonly ApiProjWebApplicationFactory _factory;

    public Part3EndpointTests(ApiProjWebApplicationFactory factory)
    {
        _factory = factory;
    }

    private static MultipartFormDataContent BuildFileContent(string fileName, string contentType)
    {
        var content = new MultipartFormDataContent();
        var file = new ByteArrayContent(new byte[] { 1, 2, 3, 4 });
        file.Headers.ContentType = new MediaTypeHeaderValue(contentType);
        content.Add(file, "file", fileName);
        return content;
    }

    [Fact]
    public async Task UploadBanner_WithoutLogin_ReturnsUnauthorized()
    {
        var client = _factory.CreateClientWithCookies();

        var response = await client.PostAsync("/api/events/1/banner", BuildFileContent("banner.png", "image/png"));

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task UploadBanner_AsParticipant_ReturnsForbidden()
    {
        var (participant, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Participant);

        var response = await participant.PostAsync("/api/events/1/banner", BuildFileContent("banner.png", "image/png"));

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task UploadBanner_ForAnotherOrganisersEvent_ReturnsForbidden()
    {
        var (organiserA, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Organiser);
        var (organiserB, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Organiser);
        var eventId = await TestHelpers.CreateEventAsync(organiserA);

        var response = await organiserB.PostAsync($"/api/events/{eventId}/banner", BuildFileContent("banner.png", "image/png"));

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task UploadBanner_WithNonImageFile_ReturnsBadRequest()
    {
        var (organiser, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Organiser);
        var eventId = await TestHelpers.CreateEventAsync(organiser);

        var response = await organiser.PostAsync($"/api/events/{eventId}/banner", BuildFileContent("notes.txt", "text/plain"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task UploadProfilePicture_WithoutLogin_ReturnsUnauthorized()
    {
        var client = _factory.CreateClientWithCookies();

        var response = await client.PostAsync("/api/users/me/profile-picture", BuildFileContent("me.png", "image/png"));

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task UploadProfilePicture_WithNonImageFile_ReturnsBadRequest()
    {
        var (participant, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Participant);

        var response = await participant.PostAsync("/api/users/me/profile-picture", BuildFileContent("cv.pdf", "application/pdf"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task GetMyEvents_AsParticipant_ReturnsForbidden()
    {
        var (participant, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Participant);

        var response = await participant.GetAsync("/api/events/mine");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task GetMyEvents_ReturnsOnlyOwnEvents_WithEnrolmentCount()
    {
        var (organiserA, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Organiser);
        var (organiserB, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Organiser);
        var eventA = await TestHelpers.CreateEventAsync(organiserA, "Organiser A Event");
        await TestHelpers.CreateEventAsync(organiserB, "Organiser B Event");
        var categoryId = await TestHelpers.CreateCategoryAsync(organiserA, eventA);

        var (participant, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Participant);
        var enrol = await participant.PostAsJsonAsync($"/api/events/{eventA}/enrolments", new EnrolRequest { CategoryId = categoryId });
        Assert.Equal(HttpStatusCode.Created, enrol.StatusCode);

        var response = await organiserA.GetAsync("/api/events/mine");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var events = await response.Content.ReadFromJsonAsync<List<EventResponse>>(TestHelpers.JsonOptions);
        Assert.Single(events!);
        Assert.Equal(eventA, events![0].EventId);
        Assert.Equal(1, events[0].EnrolmentCount);
    }

    [Fact]
    public async Task DeleteEvent_WithEnrolments_ReturnsConflict()
    {
        var (organiser, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Organiser);
        var eventId = await TestHelpers.CreateEventAsync(organiser);
        var categoryId = await TestHelpers.CreateCategoryAsync(organiser, eventId);

        var (participant, _) = await TestHelpers.CreateAuthenticatedClientAsync(_factory, UserRoles.Participant);
        await participant.PostAsJsonAsync($"/api/events/{eventId}/enrolments", new EnrolRequest { CategoryId = categoryId });

        var response = await organiser.DeleteAsync($"/api/events/{eventId}");

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }
}
