namespace mvc_proj.Models;

// One small model per page, holding exactly what that page needs to show.

public class HomeVm
{
    public string? Type { get; set; }
    public string? Location { get; set; }
    public DateTime FromDate { get; set; } = DateTime.Today;
    public List<EventDto> Events { get; set; } = new List<EventDto>();
    public string? Error { get; set; }
}

public class EventDetailsVm
{
    public EventDto Event { get; set; } = new EventDto();
    public bool IsLoggedIn { get; set; }
    public bool IsParticipant { get; set; }
    public EnrolmentDto? MyEnrolment { get; set; }
}

public class DashboardVm
{
    public List<EventDto> Events { get; set; } = new List<EventDto>();
    public string? Error { get; set; }

    public int TotalEvents => Events.Count;
    public int TotalEnrolments => Events.Sum(e => e.EnrolmentCount);
    public List<EventDto> Upcoming => Events.Where(e => e.IsUpcoming).OrderBy(e => e.EventDate).Take(5).ToList();
}

public class CategoriesPageVm
{
    public EventDto Event { get; set; } = new EventDto();
    public CategoryFormVm NewCategory { get; set; } = new CategoryFormVm();
}

public class EnrolmentsPageVm
{
    public EventDto Event { get; set; } = new EventDto();
    public List<EnrolmentDto> Enrolments { get; set; } = new List<EnrolmentDto>();
}

public class ResultRowVm
{
    public EnrolmentDto Enrolment { get; set; } = new EnrolmentDto();
    public ResultFormVm Form { get; set; } = new ResultFormVm();
}

public class ResultsPageVm
{
    public EventDto Event { get; set; } = new EventDto();
    public List<ResultRowVm> Rows { get; set; } = new List<ResultRowVm>();
}
