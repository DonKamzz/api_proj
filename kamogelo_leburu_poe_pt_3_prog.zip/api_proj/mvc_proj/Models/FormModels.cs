using System.ComponentModel.DataAnnotations;

namespace mvc_proj.Models;

// Models behind the forms. Optional fields are nullable (string?) so MVC does not
// treat them as required. Data annotations give friendly validation messages.

public class LoginVm
{
    [Required(ErrorMessage = "Please enter your email address.")]
    [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your password.")]
    public string Password { get; set; } = string.Empty;
}

public class RegisterVm
{
    [Required(ErrorMessage = "Please enter your first name.")]
    [StringLength(50, ErrorMessage = "First name can be at most 50 characters.")]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your last name.")]
    [StringLength(50, ErrorMessage = "Last name can be at most 50 characters.")]
    public string LastName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your email address.")]
    [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please choose a password.")]
    [MinLength(8, ErrorMessage = "Your password must be at least 8 characters.")]
    public string Password { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please confirm your password.")]
    [Compare(nameof(Password), ErrorMessage = "The two passwords do not match.")]
    public string ConfirmPassword { get; set; } = string.Empty;

    [StringLength(20, ErrorMessage = "Phone number can be at most 20 characters.")]
    public string? PhoneNumber { get; set; }

    [Required(ErrorMessage = "Please choose a role.")]
    public string Role { get; set; } = UserRoles.Participant;
}

public class ProfileVm
{
    [Required(ErrorMessage = "Please enter your first name.")]
    [StringLength(50)]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your last name.")]
    [StringLength(50)]
    public string LastName { get; set; } = string.Empty;

    [StringLength(20, ErrorMessage = "Phone number can be at most 20 characters.")]
    public string? PhoneNumber { get; set; }

    // Display-only values (not editable)
    public string? Email { get; set; }
    public string? Role { get; set; }
    public string? ProfilePictureUrl { get; set; }
}

public class EventFormVm
{
    public int EventId { get; set; }

    [Required(ErrorMessage = "Please enter the event name.")]
    [StringLength(150, ErrorMessage = "The name can be at most 150 characters.")]
    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }

    [Required(ErrorMessage = "Please choose the event date and time.")]
    public DateTime EventDate { get; set; } = DateTime.Today.AddDays(30).AddHours(6);

    [Required(ErrorMessage = "Please enter the location.")]
    [StringLength(150, ErrorMessage = "The location can be at most 150 characters.")]
    public string Location { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter the distance.")]
    [Range(0.01, 1000, ErrorMessage = "Distance must be between 0.01 and 1000 km.")]
    public decimal DistanceKm { get; set; }

    [Required(ErrorMessage = "Please choose an event type.")]
    public string EventType { get; set; } = "Run";

    public string? BannerImageUrl { get; set; }

    public IFormFile? BannerFile { get; set; }
}

public class CategoryFormVm
{
    public int EventId { get; set; }

    [Required(ErrorMessage = "Please enter a category name.")]
    [StringLength(50, ErrorMessage = "The category name can be at most 50 characters.")]
    public string CategoryName { get; set; } = string.Empty;

    [Range(0, 120, ErrorMessage = "Minimum age must be between 0 and 120.")]
    public int? MinAge { get; set; }

    [Range(0, 120, ErrorMessage = "Maximum age must be between 0 and 120.")]
    public int? MaxAge { get; set; }

    [Range(0.01, 1000, ErrorMessage = "Distance must be between 0.01 and 1000 km.")]
    public decimal? DistanceKm { get; set; }
}

public class ResultFormVm
{
    public int EventId { get; set; }
    public int EnrolmentId { get; set; }
    public int? ResultId { get; set; }

    [Range(0, 99, ErrorMessage = "Hours must be between 0 and 99.")]
    public int Hours { get; set; }

    [Range(0, 59, ErrorMessage = "Minutes must be between 0 and 59.")]
    public int Minutes { get; set; }

    [Range(0, 59, ErrorMessage = "Seconds must be between 0 and 59.")]
    public int Seconds { get; set; }

    [Range(1, 100000, ErrorMessage = "Finishing position must be 1 or more.")]
    public int FinishPosition { get; set; }

    [Range(1, 100000, ErrorMessage = "Total finishers must be 1 or more.")]
    public int TotalFinishers { get; set; }
}
