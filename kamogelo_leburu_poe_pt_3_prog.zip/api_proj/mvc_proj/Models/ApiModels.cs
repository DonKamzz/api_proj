namespace mvc_proj.Models;

// These classes mirror the JSON the Part 2 API sends back. The MVC app holds no
// database access and no business rules - it only displays what the API returns.

public class UserDto
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public string? ProfilePictureUrl { get; set; }
}

public class CategoryDto
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int? MinAge { get; set; }
    public int? MaxAge { get; set; }
    public decimal? DistanceKm { get; set; }

    /// <summary>Short description such as "Ages 18-39 - 21.1 km".</summary>
    public string Summary
    {
        get
        {
            var parts = new List<string>();
            if (MinAge != null && MaxAge != null) parts.Add("Ages " + MinAge + "-" + MaxAge);
            else if (MinAge != null) parts.Add("Ages " + MinAge + "+");
            else if (MaxAge != null) parts.Add("Up to age " + MaxAge);
            if (DistanceKm != null) parts.Add(DistanceKm.Value.ToString("0.##") + " km");
            return parts.Count == 0 ? "Open to all" : string.Join(" - ", parts);
        }
    }
}

public class RouteDto
{
    public int RouteId { get; set; }
    public int EventId { get; set; }
    public string RouteName { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public int? ElevationGainM { get; set; }
    public string? StartPoint { get; set; }
    public string? EndPoint { get; set; }
    public string? MapUrl { get; set; }
}

public class EventDto
{
    public int EventId { get; set; }
    public int OrganiserId { get; set; }
    public string OrganiserName { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public string EventType { get; set; } = string.Empty;
    public string? BannerImageUrl { get; set; }
    public int EnrolmentCount { get; set; }
    public List<CategoryDto> Categories { get; set; } = new List<CategoryDto>();
    public List<RouteDto> Routes { get; set; } = new List<RouteDto>();

    public string DisplayDate => EventDate.ToString("ddd, d MMM yyyy 'at' HH:mm");
    public bool IsUpcoming => EventDate >= DateTime.Now;
}

public class ResultDto
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int FinishTimeSeconds { get; set; }
    public int FinishPosition { get; set; }
    public int TotalFinishers { get; set; }
    public DateTime PublishedAt { get; set; }

    /// <summary>Finish time as h:mm:ss, e.g. 1:37:00.</summary>
    public string FinishTimeDisplay
    {
        get
        {
            var time = TimeSpan.FromSeconds(FinishTimeSeconds);
            return ((int)time.TotalHours) + ":" + time.Minutes.ToString("00") + ":" + time.Seconds.ToString("00");
        }
    }

    /// <summary>Position as text, e.g. "47th out of 312 finishers".</summary>
    public string PositionDisplay => Ordinal(FinishPosition) + " out of " + TotalFinishers + " finishers";

    public static string Ordinal(int number)
    {
        var lastTwo = number % 100;
        if (lastTwo >= 11 && lastTwo <= 13) return number + "th";

        switch (number % 10)
        {
            case 1: return number + "st";
            case 2: return number + "nd";
            case 3: return number + "rd";
            default: return number + "th";
        }
    }
}

public class EnrolmentDto
{
    public int EnrolmentId { get; set; }
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public string EnrolmentStatus { get; set; } = string.Empty;
    public DateTime EnrolmentDate { get; set; }
    public ResultDto? Result { get; set; }
}
