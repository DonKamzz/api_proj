namespace mvc_proj.Models;

public static class UserRoles
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";
}

/// <summary>Keys used to store the logged-in user's details in the MVC session.</summary>
public static class SessionKeys
{
    public const string UserId = "UserId";
    public const string Role = "Role";
    public const string FirstName = "FirstName";
    public const string ApiCookie = "ApiCookie";
}
