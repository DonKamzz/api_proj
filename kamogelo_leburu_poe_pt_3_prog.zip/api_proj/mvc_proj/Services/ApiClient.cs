using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using mvc_proj.Models;

namespace mvc_proj.Services;

/// <summary>What every call to the API gives back: success flag, data, and a friendly error.</summary>
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public HttpStatusCode StatusCode { get; set; }
    public T? Data { get; set; }
    public string? Error { get; set; }

    public bool IsUnauthorized => StatusCode == HttpStatusCode.Unauthorized;
}

/// <summary>
/// The MVC app's single gateway to the Part 2 API. The API logs users in with a
/// cookie ("RaceDayAuth"). This class keeps that cookie in the user's MVC session
/// and sends it with every request, so the API knows who is calling and what role
/// they have. Raw API/server errors are turned into friendly messages here.
/// </summary>
public class ApiClient
{
    private const string CookieName = "RaceDayAuth";
    private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _accessor;

    public ApiClient(HttpClient http, IHttpContextAccessor accessor)
    {
        _http = http;
        _accessor = accessor;
    }

    public Task<ApiResponse<T>> GetAsync<T>(string url)
    {
        return SendAsync<T>(HttpMethod.Get, url, null);
    }

    public Task<ApiResponse<T>> PostAsync<T>(string url, object? body = null)
    {
        return SendAsync<T>(HttpMethod.Post, url, ToJson(body));
    }

    public Task<ApiResponse<T>> PutAsync<T>(string url, object body)
    {
        return SendAsync<T>(HttpMethod.Put, url, ToJson(body));
    }

    public Task<ApiResponse<object>> DeleteAsync(string url)
    {
        return SendAsync<object>(HttpMethod.Delete, url, null);
    }

    /// <summary>Sends a file to the API as multipart/form-data (the API stores it in Azure Blob Storage).</summary>
    public async Task<ApiResponse<T>> PostFileAsync<T>(string url, IFormFile file)
    {
        using var content = new MultipartFormDataContent();
        using var stream = file.OpenReadStream();
        var fileContent = new StreamContent(stream);
        if (!string.IsNullOrWhiteSpace(file.ContentType))
        {
            fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        }
        content.Add(fileContent, "file", file.FileName);

        return await SendAsync<T>(HttpMethod.Post, url, content);
    }

    private static StringContent? ToJson(object? body)
    {
        if (body == null) return null;
        return new StringContent(JsonSerializer.Serialize(body, JsonOptions), Encoding.UTF8, "application/json");
    }

    private async Task<ApiResponse<T>> SendAsync<T>(HttpMethod method, string url, HttpContent? content)
    {
        try
        {
            using var request = new HttpRequestMessage(method, url);
            request.Content = content;

            // Send the user's API login cookie, if they have one
            var cookie = _accessor.HttpContext?.Session.GetString(SessionKeys.ApiCookie);
            if (!string.IsNullOrEmpty(cookie))
            {
                request.Headers.Add("Cookie", CookieName + "=" + cookie);
            }

            using var response = await _http.SendAsync(request);
            StoreCookieFrom(response);

            var body = await response.Content.ReadAsStringAsync();
            var result = new ApiResponse<T>
            {
                Success = response.IsSuccessStatusCode,
                StatusCode = response.StatusCode
            };

            if (response.IsSuccessStatusCode)
            {
                if (!string.IsNullOrWhiteSpace(body))
                {
                    try
                    {
                        result.Data = JsonSerializer.Deserialize<T>(body, JsonOptions);
                    }
                    catch (JsonException)
                    {
                        // The call worked but there was nothing readable to map - that is fine.
                    }
                }
            }
            else
            {
                result.Error = BuildErrorMessage(response.StatusCode, body);
            }

            return result;
        }
        catch (HttpRequestException)
        {
            return Failure<T>(HttpStatusCode.ServiceUnavailable,
                "We could not reach the RaceDay API. Please make sure the API is running and try again.");
        }
        catch (TaskCanceledException)
        {
            return Failure<T>(HttpStatusCode.GatewayTimeout,
                "The RaceDay API took too long to respond. Please try again.");
        }
    }

    private static ApiResponse<T> Failure<T>(HttpStatusCode status, string message)
    {
        return new ApiResponse<T> { Success = false, StatusCode = status, Error = message };
    }

    /// <summary>Keeps the session's copy of the API cookie up to date after every response.</summary>
    private void StoreCookieFrom(HttpResponseMessage response)
    {
        var session = _accessor.HttpContext?.Session;
        if (session == null) return;
        if (!response.Headers.TryGetValues("Set-Cookie", out var headers)) return;

        foreach (var header in headers)
        {
            if (!header.StartsWith(CookieName + "=", StringComparison.OrdinalIgnoreCase)) continue;

            var value = header.Substring(CookieName.Length + 1).Split(';')[0];
            if (string.IsNullOrEmpty(value))
            {
                session.Remove(SessionKeys.ApiCookie); // the API signed the user out
            }
            else
            {
                session.SetString(SessionKeys.ApiCookie, value);
            }
        }
    }

    /// <summary>Picks the most useful friendly message out of an API error response.</summary>
    private static string BuildErrorMessage(HttpStatusCode status, string body)
    {
        if (!string.IsNullOrWhiteSpace(body))
        {
            try
            {
                using var doc = JsonDocument.Parse(body);
                var root = doc.RootElement;

                if (root.ValueKind == JsonValueKind.Object)
                {
                    // Our own API errors look like { "message": "..." }
                    if (root.TryGetProperty("message", out var message) && message.ValueKind == JsonValueKind.String)
                    {
                        var text = message.GetString();
                        if (!string.IsNullOrWhiteSpace(text)) return text;
                    }

                    // Automatic validation errors look like { "errors": { "Field": ["..."] } }
                    if (root.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Object)
                    {
                        var messages = new List<string>();
                        foreach (var field in errors.EnumerateObject())
                        {
                            foreach (var item in field.Value.EnumerateArray())
                            {
                                var text = item.GetString();
                                if (!string.IsNullOrWhiteSpace(text)) messages.Add(text);
                            }
                        }
                        if (messages.Count > 0) return string.Join(" ", messages);
                    }
                }
            }
            catch (Exception ex) when (ex is JsonException || ex is InvalidOperationException)
            {
                // Not JSON (for example a plain-text server error) - fall through to the generic message.
            }
        }

        // Never show raw server output to the user.
        switch (status)
        {
            case HttpStatusCode.BadRequest: return "Please check the details you entered and try again.";
            case HttpStatusCode.Unauthorized: return "Your session has expired. Please log in again.";
            case HttpStatusCode.Forbidden: return "You do not have permission to do that.";
            case HttpStatusCode.NotFound: return "We could not find what you were looking for.";
            case HttpStatusCode.Conflict: return "That action conflicts with existing information.";
            default: return "Something went wrong on our side. Please try again in a moment.";
        }
    }
}
