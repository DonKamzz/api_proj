using System.Net;
using Microsoft.AspNetCore.Mvc;
using mvc_proj.Filters;
using mvc_proj.Models;
using mvc_proj.Services;

namespace mvc_proj.Controllers;

/// <summary>Event detail page and the enrol action, used by Participants.</summary>
public class EventsController : BaseController
{
    public EventsController(ApiClient api) : base(api)
    {
    }

    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var response = await Api.GetAsync<EventDto>("api/events/" + id);

        if (response.StatusCode == HttpStatusCode.NotFound) return NotFound();

        if (!response.Success || response.Data == null)
        {
            TempData["Error"] = response.Error;
            return RedirectToAction("Index", "Home");
        }

        var vm = new EventDetailsVm
        {
            Event = response.Data,
            IsLoggedIn = CurrentUserId != null,
            IsParticipant = CurrentRole == UserRoles.Participant
        };

        // For a logged-in Participant, check whether they are already enrolled in this event
        if (vm.IsParticipant)
        {
            var mine = await Api.GetAsync<List<EnrolmentDto>>("api/users/me/enrolments");
            var expired = HandleExpired(mine);
            if (expired != null) return expired;

            if (mine.Data != null)
            {
                vm.MyEnrolment = mine.Data.FirstOrDefault(e => e.EventId == id);
            }
        }

        return View(vm);
    }

    [HttpPost]
    [SessionAuthorize(UserRoles.Participant)]
    public async Task<IActionResult> Enrol(int eventId, int categoryId)
    {
        if (categoryId == 0)
        {
            TempData["Error"] = "Please choose a category before entering the event.";
            return RedirectToAction(nameof(Details), new { id = eventId });
        }

        var response = await Api.PostAsync<EnrolmentDto>("api/events/" + eventId + "/enrolments", new { categoryId });

        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (response.Success)
        {
            TempData["Success"] = "You are in! Your enrolment has been recorded.";
            return RedirectToAction("Enrolments", "Participant");
        }

        TempData["Error"] = response.Error;
        return RedirectToAction(nameof(Details), new { id = eventId });
    }
}
