using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using mvc_proj.Models;
using mvc_proj.Services;

namespace mvc_proj.Controllers;

public class HomeController : BaseController
{
    public HomeController(ApiClient api) : base(api)
    {
    }

    /// <summary>Upcoming events with filters. Organisers are sent to their own dashboard instead.</summary>
    [HttpGet]
    public async Task<IActionResult> Index(string? type, string? location, DateTime? fromDate)
    {
        if (CurrentRole == UserRoles.Organiser)
        {
            return RedirectToAction("Dashboard", "Organiser");
        }

        var from = fromDate ?? DateTime.Today;

        var query = new List<string>
        {
            "fromDate=" + from.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
        };
        if (!string.IsNullOrWhiteSpace(type)) query.Add("type=" + Uri.EscapeDataString(type));
        if (!string.IsNullOrWhiteSpace(location)) query.Add("location=" + Uri.EscapeDataString(location));

        var response = await Api.GetAsync<List<EventDto>>("api/events?" + string.Join("&", query));

        return View(new HomeVm
        {
            Type = type,
            Location = location,
            FromDate = from,
            Events = response.Data ?? new List<EventDto>(),
            Error = response.Success ? null : response.Error
        });
    }

    // No [HttpGet] and no anti-forgery check: when a POST fails, ASP.NET re-runs the original
    // request against this page, so it must accept any HTTP method.
    [IgnoreAntiforgeryToken]
    public IActionResult Error()
    {
        return View();
    }

    /// <summary>Friendly page for 404s and other status codes (see UseStatusCodePagesWithReExecute).</summary>
    [IgnoreAntiforgeryToken]
    public IActionResult Status(int code)
    {
        ViewBag.Code = code;
        return View();
    }
}
