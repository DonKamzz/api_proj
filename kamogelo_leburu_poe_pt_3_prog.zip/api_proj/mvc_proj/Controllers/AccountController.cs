using Microsoft.AspNetCore.Mvc;
using mvc_proj.Filters;
using mvc_proj.Models;
using mvc_proj.Services;

namespace mvc_proj.Controllers;

public class AccountController : BaseController
{
    public AccountController(ApiClient api) : base(api)
    {
    }

    // ---------------- Register ----------------

    [HttpGet]
    public IActionResult Register()
    {
        if (CurrentUserId != null) return RedirectToHome();
        return View(new RegisterVm());
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterVm model)
    {
        if (!ModelState.IsValid) return View(model);

        var body = new
        {
            firstName = model.FirstName,
            lastName = model.LastName,
            email = model.Email,
            password = model.Password,
            phoneNumber = model.PhoneNumber,
            role = model.Role
        };

        var response = await Api.PostAsync<UserDto>("api/auth/register", body);
        if (!response.Success)
        {
            ModelState.AddModelError(string.Empty, response.Error ?? "We could not create your account.");
            return View(model);
        }

        TempData["Success"] = "Your account has been created. Please log in.";
        return RedirectToAction(nameof(Login));
    }

    // ---------------- Login / Logout ----------------

    [HttpGet]
    public IActionResult Login()
    {
        if (CurrentUserId != null) return RedirectToHome();
        return View(new LoginVm());
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginVm model)
    {
        if (!ModelState.IsValid) return View(model);

        // The API checks the password and signs the user in; ApiClient keeps the API cookie in the session.
        var response = await Api.PostAsync<UserDto>("api/auth/login", new { email = model.Email, password = model.Password });
        if (!response.Success || response.Data == null)
        {
            ModelState.AddModelError(string.Empty, response.Error ?? "We could not log you in.");
            return View(model);
        }

        var user = response.Data;
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.UserId);
        HttpContext.Session.SetString(SessionKeys.Role, user.Role);
        HttpContext.Session.SetString(SessionKeys.FirstName, user.FirstName);

        return RedirectToHome();
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        // Tell the API to end its login too, then clear everything we stored in the session.
        await Api.PostAsync<object>("api/auth/logout");
        HttpContext.Session.Clear();

        TempData["Success"] = "You have been logged out.";
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult AccessDenied()
    {
        return View();
    }

    // ---------------- Profile (both roles) ----------------

    [HttpGet]
    [SessionAuthorize]
    public async Task<IActionResult> Profile()
    {
        var response = await Api.GetAsync<UserDto>("api/users/me");
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success || response.Data == null)
        {
            TempData["Error"] = response.Error;
            return RedirectToHome();
        }

        var user = response.Data;
        return View(new ProfileVm
        {
            FirstName = user.FirstName,
            LastName = user.LastName,
            PhoneNumber = user.PhoneNumber,
            Email = user.Email,
            Role = user.Role,
            ProfilePictureUrl = user.ProfilePictureUrl
        });
    }

    [HttpPost]
    [SessionAuthorize]
    public async Task<IActionResult> Profile(ProfileVm model)
    {
        if (!ModelState.IsValid) return View(model);

        var body = new { firstName = model.FirstName, lastName = model.LastName, phoneNumber = model.PhoneNumber };
        var response = await Api.PutAsync<UserDto>("api/users/me", body);

        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success)
        {
            ModelState.AddModelError(string.Empty, response.Error ?? "We could not update your profile.");
            return View(model);
        }

        HttpContext.Session.SetString(SessionKeys.FirstName, model.FirstName);
        TempData["Success"] = "Your profile has been updated.";
        return RedirectToAction(nameof(Profile));
    }

    [HttpPost]
    [SessionAuthorize]
    public async Task<IActionResult> UploadPicture(IFormFile? picture)
    {
        if (picture == null || picture.Length == 0)
        {
            TempData["Error"] = "Please choose an image first.";
            return RedirectToAction(nameof(Profile));
        }

        // The file goes to the API, which stores it in Azure Blob Storage.
        var response = await Api.PostFileAsync<UserDto>("api/users/me/profile-picture", picture);

        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (response.Success) TempData["Success"] = "Your profile picture has been updated.";
        else TempData["Error"] = response.Error;

        return RedirectToAction(nameof(Profile));
    }
}
