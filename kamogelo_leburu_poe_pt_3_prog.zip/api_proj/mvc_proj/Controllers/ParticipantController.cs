using Microsoft.AspNetCore.Mvc;
using mvc_proj.Filters;
using mvc_proj.Models;
using mvc_proj.Services;

namespace mvc_proj.Controllers;

/// <summary>Pages only a logged-in Participant can open.</summary>
[SessionAuthorize(UserRoles.Participant)]
public class ParticipantController : BaseController
{
    public ParticipantController(ApiClient api) : base(api)
    {
    }

    /// <summary>My enrolments, with colour-coded status.</summary>
    [HttpGet]
    public async Task<IActionResult> Enrolments()
    {
        var response = await Api.GetAsync<List<EnrolmentDto>>("api/users/me/enrolments");
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success) TempData["Error"] = response.Error;

        return View(response.Data ?? new List<EnrolmentDto>());
    }

    /// <summary>My results: race history across all completed events.</summary>
    [HttpGet]
    public async Task<IActionResult> Results()
    {
        var response = await Api.GetAsync<List<ResultDto>>("api/users/me/results");
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success) TempData["Error"] = response.Error;

        return View(response.Data ?? new List<ResultDto>());
    }

    [HttpPost]
    public async Task<IActionResult> Cancel(int id)
    {
        var response = await Api.DeleteAsync("api/enrolments/" + id);
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (response.Success) TempData["Success"] = "Your enrolment has been cancelled.";
        else TempData["Error"] = response.Error;

        return RedirectToAction(nameof(Enrolments));
    }
}
