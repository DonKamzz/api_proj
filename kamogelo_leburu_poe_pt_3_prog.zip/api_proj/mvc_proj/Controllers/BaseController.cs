using Microsoft.AspNetCore.Mvc;
using mvc_proj.Models;
using mvc_proj.Services;

namespace mvc_proj.Controllers;

/// <summary>Shared helpers for every controller. Controllers only ever talk to the API through ApiClient.</summary>
public abstract class BaseController : Controller
{
    protected readonly ApiClient Api;

    protected BaseController(ApiClient api)
    {
        Api = api;
    }

    protected int? CurrentUserId => HttpContext.Session.GetInt32(SessionKeys.UserId);

    protected string? CurrentRole => HttpContext.Session.GetString(SessionKeys.Role);

    /// <summary>
    /// If the API says the login has expired (401), clears the session and returns a redirect
    /// to the login page. Returns null when everything is fine.
    /// </summary>
    protected IActionResult? HandleExpired<T>(ApiResponse<T> response)
    {
        if (!response.IsUnauthorized) return null;

        HttpContext.Session.Clear();
        TempData["Error"] = "Your session has expired. Please log in again.";
        return RedirectToAction("Login", "Account");
    }

    protected IActionResult RedirectToHome()
    {
        if (CurrentRole == UserRoles.Organiser)
        {
            return RedirectToAction("Dashboard", "Organiser");
        }

        return RedirectToAction("Index", "Home");
    }

    /// <summary>All current validation messages joined into one sentence.</summary>
    protected string ModelErrors()
    {
        return string.Join(" ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
    }
}
