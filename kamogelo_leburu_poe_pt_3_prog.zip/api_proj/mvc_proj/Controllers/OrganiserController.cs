using System.Net;
using Microsoft.AspNetCore.Mvc;
using mvc_proj.Filters;
using mvc_proj.Models;
using mvc_proj.Services;

namespace mvc_proj.Controllers;

/// <summary>Everything an Organiser can do. Every action needs the Organiser role.</summary>
[SessionAuthorize(UserRoles.Organiser)]
public class OrganiserController : BaseController
{
    public OrganiserController(ApiClient api) : base(api)
    {
    }

    // ---------------- Dashboard ----------------

    [HttpGet]
    public async Task<IActionResult> Dashboard()
    {
        var response = await Api.GetAsync<List<EventDto>>("api/events/mine");
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        return View(new DashboardVm
        {
            Events = response.Data ?? new List<EventDto>(),
            Error = response.Success ? null : response.Error
        });
    }

    // ---------------- Events: list, create, edit, delete ----------------

    [HttpGet]
    public async Task<IActionResult> Events()
    {
        var response = await Api.GetAsync<List<EventDto>>("api/events/mine");
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success) TempData["Error"] = response.Error;

        return View(response.Data ?? new List<EventDto>());
    }

    [HttpGet]
    public IActionResult CreateEvent()
    {
        return View("EventForm", new EventFormVm());
    }

    [HttpPost]
    public async Task<IActionResult> CreateEvent(EventFormVm model)
    {
        if (!ModelState.IsValid) return View("EventForm", model);

        var response = await Api.PostAsync<EventDto>("api/events", ToEventBody(model));
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success || response.Data == null)
        {
            ModelState.AddModelError(string.Empty, response.Error ?? "We could not create the event.");
            return View("EventForm", model);
        }

        // The event exists now, so its banner image (if any) can be sent to the API.
        if (model.BannerFile != null && model.BannerFile.Length > 0)
        {
            var upload = await Api.PostFileAsync<EventDto>("api/events/" + response.Data.EventId + "/banner", model.BannerFile);
            if (!upload.Success)
            {
                TempData["Error"] = "The event was created, but the banner could not be uploaded. " + upload.Error;
                return RedirectToAction(nameof(EditEvent), new { id = response.Data.EventId });
            }
        }

        TempData["Success"] = "Your event has been created.";
        return RedirectToAction(nameof(Events));
    }

    [HttpGet]
    public async Task<IActionResult> EditEvent(int id)
    {
        var (ev, redirect) = await LoadOwnedEventAsync(id);
        if (redirect != null) return redirect;

        return View("EventForm", new EventFormVm
        {
            EventId = ev!.EventId,
            Name = ev.Name,
            Description = ev.Description,
            EventDate = ev.EventDate,
            Location = ev.Location,
            DistanceKm = ev.DistanceKm,
            EventType = ev.EventType,
            BannerImageUrl = ev.BannerImageUrl
        });
    }

    [HttpPost]
    public async Task<IActionResult> EditEvent(int id, EventFormVm model)
    {
        model.EventId = id;
        if (!ModelState.IsValid) return View("EventForm", model);

        var response = await Api.PutAsync<EventDto>("api/events/" + id, ToEventBody(model));
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success)
        {
            ModelState.AddModelError(string.Empty, response.Error ?? "We could not update the event.");
            return View("EventForm", model);
        }

        if (model.BannerFile != null && model.BannerFile.Length > 0)
        {
            var upload = await Api.PostFileAsync<EventDto>("api/events/" + id + "/banner", model.BannerFile);
            if (!upload.Success)
            {
                TempData["Error"] = "The event was saved, but the banner could not be uploaded. " + upload.Error;
                return RedirectToAction(nameof(EditEvent), new { id });
            }
        }

        TempData["Success"] = "Your event has been updated.";
        return RedirectToAction(nameof(Events));
    }

    [HttpPost]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var response = await Api.DeleteAsync("api/events/" + id);
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (response.Success) TempData["Success"] = "The event has been deleted.";
        else TempData["Error"] = response.Error;

        return RedirectToAction(nameof(Events));
    }

    // ---------------- Categories ----------------

    [HttpGet]
    public async Task<IActionResult> Categories(int eventId)
    {
        var (ev, redirect) = await LoadOwnedEventAsync(eventId);
        if (redirect != null) return redirect;

        return View(new CategoriesPageVm
        {
            Event = ev!,
            NewCategory = new CategoryFormVm { EventId = eventId }
        });
    }

    [HttpPost]
    public async Task<IActionResult> AddCategory(CategoryFormVm model)
    {
        if (!ModelState.IsValid)
        {
            TempData["Error"] = ModelErrors();
            return RedirectToAction(nameof(Categories), new { eventId = model.EventId });
        }

        if (model.MinAge != null && model.MaxAge != null && model.MinAge > model.MaxAge)
        {
            TempData["Error"] = "The minimum age cannot be higher than the maximum age.";
            return RedirectToAction(nameof(Categories), new { eventId = model.EventId });
        }

        var body = new
        {
            categoryName = model.CategoryName,
            minAge = model.MinAge,
            maxAge = model.MaxAge,
            distanceKm = model.DistanceKm
        };

        var response = await Api.PostAsync<CategoryDto>("api/events/" + model.EventId + "/categories", body);
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (response.Success) TempData["Success"] = "Category added.";
        else TempData["Error"] = response.Error;

        return RedirectToAction(nameof(Categories), new { eventId = model.EventId });
    }

    [HttpPost]
    public async Task<IActionResult> DeleteCategory(int id, int eventId)
    {
        var response = await Api.DeleteAsync("api/categories/" + id);
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (response.Success) TempData["Success"] = "Category removed.";
        else TempData["Error"] = response.Error;

        return RedirectToAction(nameof(Categories), new { eventId });
    }

    // ---------------- Enrolments ----------------

    [HttpGet]
    public async Task<IActionResult> Enrolments(int eventId)
    {
        var (ev, redirect) = await LoadOwnedEventAsync(eventId);
        if (redirect != null) return redirect;

        var response = await Api.GetAsync<List<EnrolmentDto>>("api/events/" + eventId + "/enrolments");
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success) TempData["Error"] = response.Error;

        return View(new EnrolmentsPageVm
        {
            Event = ev!,
            Enrolments = response.Data ?? new List<EnrolmentDto>()
        });
    }

    // ---------------- Results ----------------

    [HttpGet]
    public async Task<IActionResult> Results(int eventId)
    {
        var (ev, redirect) = await LoadOwnedEventAsync(eventId);
        if (redirect != null) return redirect;

        var response = await Api.GetAsync<List<EnrolmentDto>>("api/events/" + eventId + "/enrolments");
        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (!response.Success) TempData["Error"] = response.Error;

        var enrolments = response.Data ?? new List<EnrolmentDto>();
        var rows = new List<ResultRowVm>();

        foreach (var enrolment in enrolments)
        {
            var form = new ResultFormVm
            {
                EventId = eventId,
                EnrolmentId = enrolment.EnrolmentId,
                TotalFinishers = enrolments.Count
            };

            // If a result is already captured, show it so the Organiser can correct it
            if (enrolment.Result != null)
            {
                form.ResultId = enrolment.Result.ResultId;
                form.Hours = enrolment.Result.FinishTimeSeconds / 3600;
                form.Minutes = (enrolment.Result.FinishTimeSeconds % 3600) / 60;
                form.Seconds = enrolment.Result.FinishTimeSeconds % 60;
                form.FinishPosition = enrolment.Result.FinishPosition;
                form.TotalFinishers = enrolment.Result.TotalFinishers;
            }

            rows.Add(new ResultRowVm { Enrolment = enrolment, Form = form });
        }

        return View(new ResultsPageVm { Event = ev!, Rows = rows });
    }

    [HttpPost]
    public async Task<IActionResult> SaveResult(ResultFormVm model)
    {
        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Please check the result details. " + ModelErrors();
            return RedirectToAction(nameof(Results), new { eventId = model.EventId });
        }

        if (model.FinishPosition > model.TotalFinishers)
        {
            TempData["Error"] = "The finishing position cannot be higher than the total number of finishers.";
            return RedirectToAction(nameof(Results), new { eventId = model.EventId });
        }

        var totalSeconds = model.Hours * 3600 + model.Minutes * 60 + model.Seconds;
        if (totalSeconds <= 0)
        {
            TempData["Error"] = "Please enter a finish time greater than zero.";
            return RedirectToAction(nameof(Results), new { eventId = model.EventId });
        }

        ApiResponse<ResultDto> response;

        if (model.ResultId.HasValue)
        {
            // A result already exists: correct it
            response = await Api.PutAsync<ResultDto>("api/results/" + model.ResultId.Value, new
            {
                finishTimeSeconds = totalSeconds,
                finishPosition = model.FinishPosition,
                totalFinishers = model.TotalFinishers
            });
        }
        else
        {
            // First result for this enrolment: capture and publish it
            response = await Api.PostAsync<ResultDto>("api/events/" + model.EventId + "/results", new
            {
                enrolmentId = model.EnrolmentId,
                finishTimeSeconds = totalSeconds,
                finishPosition = model.FinishPosition,
                totalFinishers = model.TotalFinishers
            });
        }

        var expired = HandleExpired(response);
        if (expired != null) return expired;

        if (response.Success) TempData["Success"] = "Result saved and published.";
        else TempData["Error"] = response.Error;

        return RedirectToAction(nameof(Results), new { eventId = model.EventId });
    }

    // ---------------- Helpers ----------------

    private static object ToEventBody(EventFormVm model)
    {
        return new
        {
            name = model.Name,
            description = model.Description,
            eventDate = model.EventDate,
            location = model.Location,
            distanceKm = model.DistanceKm,
            eventType = model.EventType,
            bannerImageUrl = model.BannerImageUrl
        };
    }

    /// <summary>Loads an event and confirms it belongs to the logged-in Organiser; otherwise returns a redirect.</summary>
    private async Task<(EventDto? ev, IActionResult? redirect)> LoadOwnedEventAsync(int id)
    {
        var response = await Api.GetAsync<EventDto>("api/events/" + id);

        var expired = HandleExpired(response);
        if (expired != null) return (null, expired);

        if (response.StatusCode == HttpStatusCode.NotFound) return (null, NotFound());

        if (!response.Success || response.Data == null)
        {
            TempData["Error"] = response.Error;
            return (null, RedirectToAction(nameof(Events)));
        }

        if (response.Data.OrganiserId != CurrentUserId)
        {
            TempData["Error"] = "You can only manage events that you created.";
            return (null, RedirectToAction(nameof(Events)));
        }

        return (response.Data, null);
    }
}
