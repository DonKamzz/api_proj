using Microsoft.AspNetCore.Mvc;
using mvc_proj.Services;

var builder = WebApplication.CreateBuilder(args);

// ---------- MVC (every POST form is protected by an anti-forgery token) ----------
builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
});

// ---------- Session: stores the logged-in user's ID, role and name ----------
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = "RaceDay.Session";
    options.IdleTimeout = TimeSpan.FromMinutes(20);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
builder.Services.AddHttpContextAccessor();

// ---------- The ONLY way this app gets data: HTTP calls to the Part 2 API ----------
var apiBaseUrl = builder.Configuration["ApiSettings:BaseUrl"] ?? "https://localhost:5001/";
var allowUntrusted = builder.Configuration.GetValue<bool>("ApiSettings:AllowUntrustedCertificate");

builder.Services.AddHttpClient<ApiClient>(client =>
{
    client.BaseAddress = new Uri(apiBaseUrl.TrimEnd('/') + "/");
    client.Timeout = TimeSpan.FromSeconds(30);
}).ConfigurePrimaryHttpMessageHandler(() =>
{
    // UseCookies = false: ApiClient attaches the API's login cookie itself, from the user's session.
    var handler = new HttpClientHandler { UseCookies = false };

    // Only for local development / Docker, where the API uses a self-signed dev certificate.
    if (allowUntrusted)
    {
        handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
    }

    return handler;
});

var app = builder.Build();

// Users never see raw errors: exceptions and 404s go to friendly pages.
app.UseExceptionHandler("/Home/Error");
app.UseStatusCodePagesWithReExecute("/Home/Status", "?code={0}");

app.UseStaticFiles();
app.UseRouting();
app.UseSession();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
