# RaceDay - Parts 2 & 3: REST API and MVC Web App

**Module:** PROG6212/w - Programming 2B
**Student:** Kamogelo Leburu (ST10459758)
**Assessment:** Portfolio of Evidence - Part 2 (RESTful API) and Part 3 (MVC web app, Azure Blob Storage, Docker)

RaceDay is an event management platform for South African running, walking and cycling events.
Organisers create and manage events, categories and results; Participants browse events, enter them and track their results.

## Solution structure

```
api_proj.sln
|-- api_proj/            Part 2 + 3: ASP.NET Core Web API (EF Core, cookie auth, Swagger, Azure Blob Storage)
|-- api_proj.Tests/      xUnit tests (run against the real HTTP pipeline, in-memory database)
|-- mvc_proj/            Part 3: ASP.NET Core MVC web app - consumes the API, no database access
|   |-- Controllers/     Account, Home, Events, Participant, Organiser
|   |-- Services/        ApiClient - the only way the MVC app gets data (HTTP calls to the API)
|   |-- Filters/         SessionAuthorize - session-based login and role checks
|   |-- Views/           Razor views (Bootstrap + RaceDay theme in wwwroot/css/site.css)
|   `-- Dockerfile
|-- docker-compose.yml
|-- docs/part3_api_additions.md
`-- .github/workflows/dotnet-ci.yml
```

## The two roles

| Role | What they can do |
|---|---|
| **Organiser** | Dashboard, create/edit/delete events with a banner image, add/remove categories, view enrolments, capture and publish results. |
| **Participant** | Browse and filter upcoming events, view event details and categories, enter an event by choosing a category, see enrolments and their status, see race results, update profile and profile picture. |

## How the MVC app talks to the API

1. The MVC app has **no database code and no business rules**. Every page calls the API through `Services/ApiClient.cs`.
2. On login, the API signs the user in with its `RaceDayAuth` cookie. `ApiClient` keeps that cookie in the user's **MVC session** and sends it with every later API call, so the API still enforces roles.
3. The MVC **session** also stores the user's ID, role and first name. `[SessionAuthorize]` redirects visitors who are not logged in to the login page, and sends the wrong role to an "access denied" page. Logging out clears the session and signs out of the API.
4. Images: the MVC app sends the file to the API (`multipart/form-data`). **Only the API talks to Azure.** The API stores the image in Azure Blob Storage and saves the URL in the database; the MVC app displays that URL.
5. Errors from the API are turned into friendly messages in `ApiClient`. Unhandled errors and 404s show a friendly page - never a raw error.

## Setup and running

### 1. Database
Create `RaceDayDB` on your SQL Server instance (the connection string in `api_proj/appsettings.json` uses `(localdb)\PROGPOE`):
run `raceday_schema.sql` from Part 1 in SSMS, **or** use migrations (`Add-Migration InitialCreate` then `Update-Database` in the Package Manager Console with `api_proj` as the Default project).

### 2. Azure Blob Storage (for banner and profile images)
1. In the Azure portal create a **Storage account**. Under *Configuration*, make sure **Allow Blob anonymous access** is **Enabled** (so images can be shown on the site).
2. Under *Access keys*, copy a **Connection string**.
3. In Visual Studio right-click `api_proj` > **Manage User Secrets** and paste (keeps the key out of GitHub):
   ```json
   {
     "AzureBlobStorage": {
       "ConnectionString": "<your storage account connection string>"
     }
   }
   ```
   The API creates the `raceday-images` container (public read for blobs) the first time an image is uploaded.
   Without a connection string everything else works; uploads show "Image storage has not been configured".

### 3. Run the API and the MVC app together
Right-click the solution > **Configure Startup Projects** > *Multiple startup projects* > set `api_proj` and `mvc_proj` to **Start**, then press F5.
- API + Swagger: https://localhost:5001/swagger
- MVC web app: http://localhost:5100

The MVC app reads the API address from `mvc_proj/appsettings.json` (`ApiSettings:BaseUrl`).

### 4. Run in Docker (MVC app)
The Part 2 API keeps running from Visual Studio (https://localhost:5001). Then, from the repository root:

```
docker compose up --build
```

or, with plain Docker:

```
docker build -f mvc_proj/Dockerfile -t raceday-mvc .
docker run -p 8080:8080 -e ApiSettings__BaseUrl=https://host.docker.internal:5001/ -e ApiSettings__AllowUntrustedCertificate=true raceday-mvc
```

Open http://localhost:8080. The container behaves the same as running locally: the only difference is the API address, which is passed in as `ApiSettings__BaseUrl` (`host.docker.internal` is how a container reaches the host machine). `AllowUntrustedCertificate` is only for the API's self-signed development certificate - never use it in production.

### 5. Unit tests
```
dotnet test api_proj.sln
```
| Test class | Covers |
|---|---|
| `AuthTests` | Register, login (success and failure), cookie-gated access, logout |
| `EventManagementTests` | Organiser CRUD on events, ownership, validation, 404 |
| `RoleEnforcementTests` | Wrong role / not logged in rejected from role-based endpoints |
| `EnrolmentTests` | Participant enrolment recorded, duplicates, 404/401 |
| `Part3EndpointTests` | Organiser dashboard list, image upload role and validation checks, delete-with-enrolments conflict |

## Try it: quick demo flow
1. Sign up as an **Organiser**, log in, **Create an event** (add a banner image), open **Categories** and add one.
2. Log out. Sign up as a **Participant**, log in, open the event from the home page, pick a category and **Enter event**. Check **My enrolments** (green = Confirmed).
3. Log out, log in as the Organiser: the **Dashboard** shows the enrolment. Open **Results**, enter a finish time and position, Save.
4. Log back in as the Participant: **My results** shows the time and "1st out of 1 finishers".

## Part 3 rubric - where each item is
| Rubric criterion | Where it is addressed |
|---|---|
| Correct submission | This README (setup, Docker run command, video link), `mvc_proj/Dockerfile`, full source |
| GitHub and CI/CD | `.github/workflows/dotnet-ci.yml` builds the API, the MVC app and the tests, runs the tests, and builds the Docker image |
| Authentication and role-based navigation | `AccountController` (register, login, logout), session storing user ID and role, `SessionAuthorizeAttribute`, role-specific menus in `Views/Shared/_Layout.cshtml` |
| Organiser interface | `OrganiserController` + `Views/Organiser`: dashboard, events (create/edit/delete + banner), categories, enrolments, results entry |
| Participant interface | `HomeController` (events + filters), `EventsController` (details + enrol), `ParticipantController` (my enrolments, my results), `AccountController` (profile + picture) |
| Azure Blob Storage | `api_proj/Services/BlobStorageService.cs`, `POST /api/events/{id}/banner`, `POST /api/users/me/profile-picture`; MVC only calls the API |
| Docker | `mvc_proj/Dockerfile` (multi-stage, non-root), `docker-compose.yml`, commands above |
| UI design | Bootstrap + `wwwroot/css/site.css`: RaceDay colours and fonts, colour-coded statuses, consistent layout, validation and friendly error pages |
| Video | Link below |

## CI/CD
`.github/workflows/dotnet-ci.yml` runs on every push: restores, builds `api_proj`, `mvc_proj` and `api_proj.Tests` in Release, runs the tests, and (separate job) builds the MVC Docker image.

**CI screenshot:** _add a screenshot of the green GitHub Actions run here before submission._

## Video
**YouTube (unlisted) - full application, MVC pages, Blob Storage integration and Docker setup:** _add link here before submission._

## AI disclosure
AI assistance was used to scaffold and write parts of the API, MVC app, tests and documentation from the Part 1 plan and the course build guide. The student is responsible for reviewing, building, running and understanding all code before submission, and for explaining it in the video.

**Before you submit:** this code was written without a .NET SDK available to compile it. Open the solution in Visual Studio, restore packages, build, run `dotnet test`, then walk through the demo flow above (including a real image upload to Azure and the Docker run) and fix anything that differs.
